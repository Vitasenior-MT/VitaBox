'use strict';
// Testing for browser support
var speechSynthesisSupported = 'speechSynthesis' in window;
speechVoices.setDefaultVoice("Portuguese Female");

var socket = io();
var sound = true;
var remoteOldHdmiState = 0;
var msgOldHdmiState = 0;

//for teste for now
var timeCount = 0;
var timeToWait = 1000;
var waitingTime;
var messageConfirmed = true;
var messageTimerCount = 0;
// menus
var menuKeyIndex = 1;
var maxMenus;
// end menus
var keyEventRelease = true;
var remoteKeys = [];
var modalMsg = [];
// Get the modal
var modalObj = document.getElementById('Modal');
var textReadableJson = {};

var messageCount = 0;
var multiMessage = [];