'use strict';

var appendToTextArea = function (msg) {
    $('#outputTextarea').val(function (i, text) {
        return text + JSON.stringify(msg, undefined, 2) + "\n----------------------------\n";
    });
    $('#outputTextarea').scrollTop($('#outputTextarea')[0].scrollHeight);
}

var checkIndexMenu = function () {
    maxMenus = $(".btn-menu").length;
};

var readText = function (text) {
    responsiveVoice.cancel();
    speechSynthesis.cancel();
    speechVoices.cancel();
    switch (menuKeyIndex) {
        case 1:
            console.log(menuKeyIndex + ': ' + text);
            //responsiveVoice.speak(text);
            speechVoices.speak(text);
            break;
        case 2:
            console.log(menuKeyIndex + ': ' + text);
            //responsiveVoice.speak(text);
            speechVoices.speak(text);
            break;
        case 3:
            console.log(menuKeyIndex + ': ' + text);
            //responsiveVoice.speak(text);
            speechVoices.speak(text);
            break;
        case 4:
            console.log(menuKeyIndex + ': ' + text);
            //responsiveVoice.speak(text);
            speechVoices.speak(text);
            break;
        case 5:
            console.log(menuKeyIndex + ': ' + text);
            //responsiveVoice.speak(text);
            speechVoices.speak(text);
            break;
        default:
            console.log(menuKeyIndex + ': ' + text);
            //responsiveVoice.speak(text);
            speechVoices.speak(text);
            break;
    }
};

var timer = function (waitTime) {
    var intervalObject = setInterval(function () {
        timeCount++;
        console.log(timeCount, 'seconds passed');
        if (timeCount == waitTime) {
            console.log('exiting');
            timeCount = 0;
            keyEventRelease = true;
            clearInterval(intervalObject);
        }
    }, timeToWait);
}

var closeModal = function () {
    modalObj.style.display = "none";
    messageCount = 0;
    responsiveVoice.cancel();
    speechSynthesis.cancel();
    speechVoices.cancel();
    messageConfirmed = true;
}

var modal = function (header, message, footer) {
    modalObj.style.display = "block";
    console.log($(".header").innerHTML);
    if (header) {
        var text = '';
        for (var i = 0; i < message.length; i++) {
            text += message[i].location + '. ';
            for (var index = 0; index < message[i].data.length; index++) {
                text += message[i].data[index].message + '';
            }
        }
        readText(header + '    ' + text + '    ' + footer);
    } else {
        readText($(".header").text() + '    ' + $(".message").text() + '    ' + $(".footer").text());
    }
}

function buildModal(headerMsg, multiMessage, footerMsg, color) {
    var data = {
        'msgNumber': messageCount,
        'headerMsg': headerMsg,
        'multiMessage': multiMessage,
        'footerMsg': footerMsg,
        'color': color
    };
    $('#Modal').html($('#modal-template').tmpl(data));
    $("#modalWindow").modal();
}

var keyEvents = function (code) {
    for (var obj in remoteKeys) {
        var key = remoteKeys[obj];
        if (code === key.code) {
            if (key.timed_flg) {
                if (keyEventRelease) {
                    keyEventProcessing(key.task);
                    keyEventRelease = false;
                    timer(waitingTime);
                }
            } else {
                keyEventProcessing(key.task);
            }
            break;
        }
    }
}

var keyEventProcessing = function (cmd) {
    if (!messageConfirmed) {
        if (cmd === 'ok_btn') {
            if (modalObj.style.display === "block") {
                closeModal();
                messageConfirmed = true;
                multiMessage = [];
                socket.emit("vitaCMD", 'tx 4F:82:' + msgOldHdmiState + '0:00');
            }
        }
    } else {
        console.log(cmd);
        switch (cmd) {
            case "ch_1":
                socket.emit('vitaCMD', 'tx 4F:82:10:00', true, 'remote');
                break;
            case "ch_2":
                socket.emit('vitaCMD', 'tx 4F:82:20:00', true, 'remote');
                break;
            case "hdmirequest":
                socket.emit("hdmiCurrentStateRequest");
                break;
            case "var_state":
                socket.emit('vitaCMD', 'tx 4F:82:00:00');
                console.log('remote: ', remoteOldHdmiState);
                console.log('msg: ', msgOldHdmiState);
                break;
            case "left":
                menuScroll(-1);
                break;
            case "right":
                menuScroll(1);
                break;
            case "ok_btn":
                if (modalObj.style.display === "none") {
                    socket.emit("vitaCMD", 'tx 4F:82:' + remoteOldHdmiState + '0:00');
                }
                break;
            default:
                break;
        }
    }
}

var menuScroll = function (signal) {
    menuKeyIndex = menuKeyIndex + (1 * signal);
    console.log(menuKeyIndex);
    if (menuKeyIndex > maxMenus) {
        menuKeyIndex = 1;
    }

    if (menuKeyIndex < 1) {
        menuKeyIndex = maxMenus;
    }

    $("#btn-menu-" + (menuKeyIndex)).click();
}

var stateTimer = function (wait) {
    var time = 0;
    var intervalObject = setInterval(function () {
        time++;
        if (time === wait) {
            console.log('here to restart');
            clearInterval(intervalObject);
            socket.emit("hdmiCurrentStateRequest");
        }
    }, timeToWait);
}

Array.prototype.containsLocation = function (location) {
    var i = this.length;
    while (i--)
        if (this[i].location == location) {
            return { contains: true, index: i };
        }
    return { contains: false, index: -1 };
}

Array.prototype.containsData = function (warning_type, avg) {
    var i = this.length;
    while (i--)
        if (warning_type === this[i].warning_type) {
            this[i].avg = avg;
            return true;
        }
    return false;
}

Array.prototype.findByWarningType = function (warning_type) {
    var i = this.length;
    while (i--)
        if (warning_type === this[i].warning_type)
            return this[i];
    return false;
}

var buildWarnings = function (data) {
    console.log('warnings: ', data);
    var currentMessageModel = modalMsg.findByWarningType(data.warning_type);
    var isMulti = false;
    if (multiMessage.length < 1) {
        multiMessage.push({
            location: data.location,
            data: [{
                warning_type: data.warning_type,
                message: currentMessageModel.message,
                avg: data.avg
            }]
        });
    } else {
        isMulti = true;
        var message = multiMessage.containsLocation(data.location);
        if (!message.contains) {
            multiMessage.push({
                location: data.location,
                data: [{
                    warning_type: data.warning_type,
                    message: currentMessageModel.message,
                    avg: data.avg
                }]
            });
        } else {
            if (multiMessage[message.index].data.length < 1) {
                multiMessage[message.index].data.push({
                    warning_type: data.warning_type,
                    message: currentMessageModel.message,
                    avg: data.avg
                });
            } else if (!multiMessage[message.index].data.containsData(data.warning_type, data.avg)) {
                multiMessage[message.index].data.push({
                    warning_type: data.warning_type,
                    message: currentMessageModel.message,
                    avg: data.avg
                });
            }
        }
    }

    messageCount++;
    menuKeyIndex = 999;//TODO: only for testing speech remove later
    if (isMulti) {
        currentMessageModel = modalMsg.findByWarningType('all');
    }
    buildModal(currentMessageModel.header, multiMessage, currentMessageModel.footer, currentMessageModel.color);
    modal(currentMessageModel.header, multiMessage, currentMessageModel.footer);
}