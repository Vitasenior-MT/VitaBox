'use strict';

$(document).ready(function () {

	$(".btn-menu").click(function () {
		$(".btn-menu").removeClass("btn-info").addClass("btn-success");
		$(this).removeClass("btn-success").addClass("btn-info");
		$(".container-tab").removeClass("show").removeClass(" active").addClass("fade");
		var idComtainer = "#" + $(this).attr("id").replace("btn-menu", "container");
		$(idComtainer).addClass("show").addClass(" active").removeClass("fade");
		(textReadableJson === null) ? '' : readText(textReadableJson[this.id]);
	});

	$('#selectOpt').change(function (e) {
		var optionSelected = $("option:selected", this);
		var valueSelected = this.value;
		// console.log(optionSelected, valueSelected);
		$("#selected-text-input").val(this.value);
	});

	$("#rumCommandCec").click(function () {
		if ($("#selected-text-input").val().trim() !== "") {
			var command = $("#selected-text-input").val().trim();
			socket.emit('execCommandCEC', command);
		}
	});

	$("#rumCommandCec2").click(function () {
		if ($("#selected-text-input2").val().trim() !== "") {
			var command = $("#selected-text-input2").val().trim();
			socket.emit('execCommandCECPlusInfo', command, 1);
		}
	});

	$('#selectOpt2').change(function (e) {
		var optionSelected = $("option:selected", this);
		var valueSelected = this.value;
		$("#selected-text-input2").val(this.value);
	});

	$("#rumCommandCecHDMI").click(function () {
		if ($("#selected-text-inputHDMI").val().trim() !== "") {
			var command = $("#selected-text-inputHDMI").val().trim();
			console.log(command);
			socket.emit('execCommandCECHDMI', command);
		}
	});

	$('#selectOptHDMI').change(function (e) {
		var optionSelected = $("option:selected", this);
		var valueSelected = this.value;
		$("#selected-text-inputHDMI").val(this.value);
	});

	$("#rumSendMsg").click(function () {
		var msg = $("#msg-text-input").val().trim();
		if (msg.length <= 13 & msg !== "") {
			socket.emit('rumSendMsg', {
				msg: $("#msg-text-input").val(),
				optmsg: $("#selectOptMsg option:selected").val()
			});
		} else {
			alert("Mensagem vazia ou com um comprimento superior a 13 carateres.");
		}
	});

	$("#rumSendMsgtx").click(function () {
		if ($("#msg-text-input-tx").val().trim() !== "") {
			socket.emit('runTxCmd', $("#msg-text-input-tx").val().trim(), false);
		}
	});

	socket.on('hdmistatus', function (data) {
		console.log("Data", data);
		appendToTextArea(data);
	});

	socket.on('settings', function (data, type) {
		console.log("Data", data);
		switch (type) {
			case 'remote':
				for (var index in data) {
					remoteKeys.push({
						code: data[index].code,
						name: data[index].name,
						task: data[index].task,
						timed_flg: data[index].timed_flg
					});
				}
				break;
			case 'settings':
				waitingTime = data[0].waiting_time;
				break;
			case 'warnings':
				for (var index in data) {
					modalMsg.push({
						color: data[index].color,
						footer: data[index].footer,
						header: data[index].header,
						message: data[index].message,
						warning_type: data[index].warning_type
					});
				}

				break;
		}
	});

	socket.on('msgOutput', function (output) {
		appendToTextArea(output);
	});

	socket.on('console.log', function (info) {
		console.log(info);
	});

	socket.on('sendPath', function (path) {
		absolutePath = path;
	});

	socket.on('sendRawData', function (data) {
		console.log("-------------------------");
		console.log(data);
		console.log(data.hdmiRawData);
		console.log("-------------------------");
	});

	socket.on('settingsData', function (data) {
		console.log(data);
		var dataSettings = data.settings;
		textReadableJson = data.textReadable;
		checkIndexMenu();
		$("#loader").css("display", "none");
		$(".container-fluid").css("display", "");
	});

	socket.on("ready", function (data) {
		console.log("ready", data);
	});

	socket.on('vita-warning', function (data) {
		buildWarnings(data);
		if (messageConfirmed) {
			socket.emit("vitaCMD", 'as', true, 'msg');
			messageConfirmed = false;
		}
	});

	socket.on("hdmiCurrentStatePost", function (state, type) {
		var hdmi;

		if (state.PhysAddress === 0) {
			stateTimer(3);
		} else {
			hdmi = parseInt(state.PhysAddress.split('.')[0]);
		}

		switch (type) {
			case 'remote':
				remoteOldHdmiState = hdmi;
				break;
			case 'msg':
				msgOldHdmiState = hdmi;
				break;
			default:
				break;
		}
		console.log("state: ", hdmi);
		console.log("remoteOldHdmiState: ", remoteOldHdmiState);
		console.log("msgOldHdmiState: ", msgOldHdmiState);
	});

	socket.on("status", function (data) {
		console.log("status", data);

	});

	socket.on("datakey", function (data) {
		console.log("datakey", data);
		keyEvents(data.code);
	});

	socket.on("error", function (data) {
		console.log("error", data);
	});
});