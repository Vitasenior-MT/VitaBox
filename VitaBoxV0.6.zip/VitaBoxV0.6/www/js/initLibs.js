'use strict';

function start(callback) {
    $("#navBar").load("html/navBar/navBar.html");
    $("#modalTemplate").load("html/templates/modalsTemplate.html");
    $("#container-1").load("html/pages/outputs.html");
    if (typeof callback === 'function') {
        callback();
    }
}

function end() {
    $("#initLibs").load("html/initLibs.html");
    $("head").load("html/header/head.html");
}

start(end);