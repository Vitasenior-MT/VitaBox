#1. Install nodejs
wget https://nodejs.org/dist/v8.9.2/node-v8.9.2-linux-armv6l.tar.gz
sudo tar -xzf node-v8.9.2-linux-armv6l.tar.gz
sudo cp -rf node-v8.9.2-linux-armv6l nodejs
sudo rm node-v8.9.2-linux-armv6l.tar.gz
sudo rm -rf node-v8.9.2-linux-armv6l
sudo rm -f /usr/bin/node
sudo rm -f /usr/bin/npm
sudo ln -s /opt/nodejs/bin/node /usr/bin/node
sudo ln -s /opt/nodejs/bin/npm /usr/bin/npm

#2. Config autostart
sudo cp nodeAutostart.service /etc/systemd/system/nodeAutostart.service
sudo systemctl enable nodeAutostart.service
sudo systemctl start nodeAutostart.service
sudo systemctl stop nodeAutostart.service

#3. Chromium config and autostart
sudo echo "@sh /home/pi/Desktop/VitaBox/autoStartChrome.sh" >> /home/pi/.config/lxsession/LXDE-pi/autostart
sudo sed -i -e 's/\r$//' autoStartChrome.sh
sudo chmod +x autoStartChrome.sh

#4. Installers
npm install
sudo apt-get update
sudo apt-get upgrade
sudo apt-get install chromium-browser
sudo apt-get install xscreensaver
sudo apt-get install cec-utils
sudo apt-get install mongodb
sudo reboot