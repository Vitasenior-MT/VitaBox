var cp = require('child_process');
var Main = function () {
  var vitaBox = cp.fork('./lib/server.js');
  vitaBox.send({ "serverdata": { port: 8088 } });

  //var hub = cp.fork('./lib/hub/hub.js');
  //hub.send({ "serverdata2": { port: 8089 } });
};

new Main();

module.exports = Main;